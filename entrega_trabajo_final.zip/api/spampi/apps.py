from django.apps import AppConfig


class SpampiConfig(AppConfig):
    name = 'spampi'
